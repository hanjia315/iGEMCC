---
title: "About this Site"
layout: "default"
isPage: true
isPost: false
---

This is the Home Site of iGEM China Community

We are working hard to build a nice website!

*By S-force of iGEM CC Team*
