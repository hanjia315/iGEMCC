---
title: Template Post
layout: post
isPage: false
isPost: true
date: 0000-00-00
---

This is the the first post of iGEM China Community as a template!
